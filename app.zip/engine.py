#importing following modules for security checkup modules
import socket 
import subprocess
import os 
import sys
#data_modules 
from data import MISSING_NUMBER , PRESENT_NUMBER , GENERAL_NUMBER_INFORMATION
class NCEU:
    def __init__(self,dd,mm,yy,name,gender,y_sound_factor:bool):
        self.d = dd
        self.m = mm
        self.y = yy
        self.n = str(name).lower()
        self.g = gender
        self.ysf = y_sound_factor
        self.master_number = [int(i+1)*11 for i in range(6)]
        self.chaldean_chart = {"a":"1","b":"2","c":"3","d":"4","e":"5","f":"8","g":"3","h":"5","i":"1","j":"1","k":"2","l":"3","m":"4","n":"5","o":"7","p":"8","q":"1","r":"2","s":"3","t":"4","u":"6","v":"6","w":"6","x":"5","y":"1","z":"7"}
        self.missing_number = MISSING_NUMBER
        self.present_number = PRESENT_NUMBER
        self.gni = GENERAL_NUMBER_INFORMATION
    def unitization(self,dig):
        self.sum = [int(i) for i in str(sum(dig))]
        if len(self.sum) == 1:
            return self.sum[0] 
        return self.unitization(self.sum)
    def compound(self,u):
        o = 0
        for i in u:
            o += i
        return o
    def chaldean_name_numerology(self):
        self.un = [int(self.chaldean_chart[i]) for i in list(self.n) if i != " " ]
        return {"c":sum(self.un),"s":self.unitization(self.un)}
    def kua(self):
        self.yy = [int(i) for i in str(self.y)]
        if self.g == 'male':
            self.kua_u = [int(j) for j in str(11 - self.unitization(self.yy))]
            return self.unitization(self.kua_u)
        else:
            self.kua_u = [int(j) for j in str(4+ self.unitization(self.yy))]
            return self.unitization(self.kua_u)
    def soul_expression_number(self):
        self.fn = [i for i in list(self.n) if i != " "]
        self.s = []
        self.e = []
        if (self.ysf):
            for i in self.fn:
                if(i == 'a' or i == 'e' or i =='i' or i == 'o' or i =='u' or i =='y'):
                    self.s.append(int(self.chaldean_chart[i]))
                else:
                    self.e.append(int(self.chaldean_chart[i]))
        else:
            for i in self.fn:
                if(i == 'a' or i == 'e' or i =='i' or i == 'o' or i =='u'):
                    self.s.append(int(self.chaldean_chart[i]))
                else:
                    self.e.append(int(self.chaldean_chart[i]))
        return {"soul":self.unitization(self.s),"expression":self.unitization(self.e)}
    def lsg(self):
        self.pp = dict()
        self.mm = dict()
        self.grid = {"1": "", "2": "", "3": "","4": "", "5": "", "6": "", "7": "", "8": "", "9": ""}
        self.al = [int(i) for i in str(self.d)] + [int(i) for i in str(self.m)] + [int(i) for i in str(self.y)]
        self.al = [i for i in self.al if i != 0] + [self.general_calculation()["moolank"],self.general_calculation()['bhagyank']]
        if self.general_calculation()['kua'] in self.al:
            pass
        else:
            self.al = self.al +[ self.general_calculation()['kua'] ]
        if self.general_calculation()['name']['s'] in self.al:
            pass
        else:
            self.al = self.al + [self.general_calculation()['name']['s']]
        for i in self.al:
            self.grid[str(i)] += str(i)
        self.uio = list(self.grid.items())
        for i , j in self.uio:
            if  j  == '':
                self.mm[str(i)] =self.missing_number[str(i)]
            else:
                self.pp[str(i)] =self.present_number[str(i)]
        return {
            "grid":self.grid,
            "information":{
                "missing":self.mm,
                "present":self.pp
            }
        }
    def vg(self):
        self.gridd = {"1": "", "2": "", "3": "","4": "", "5": "", "6": "", "7": "", "8": "", "9": ""}
        self.ale = [int(i) for i in str(self.d)] + [int(i) for i in str(self.m)] + [int(i) for i in str(self.y)][1::]
        self.ale = [i for i in self.ale if i != 0]
        for i in self.ale:
            self.gridd[str(i)] += str(i)
        return {"vg":self.gridd}
    def general_calculation(self):
        self.d_u = [int(i) for i in str(self.d)]
        self.m_u = [int(i) for i in str(self.m)]
        self.y_u = [int(i) for i in str(self.y)]
        self.all = self.d_u + self.m_u + self.y_u
        self.moolank =  self.unitization(self.d_u)
        self.bhagyank = self.unitization(self.all)
        self.name_number = self.chaldean_name_numerology()
        self.kua_number = self.kua()
        self.bhagyank_compound = sum(self.all)
        self.soul = self.soul_expression_number()
        return {
            "moolank":self.moolank,
            "bhagyank":self.bhagyank,
            "bhagyank_c":self.bhagyank_compound,
            "kua":self.kua_number,
            "name":self.name_number,
            "soul":self.soul['soul'],
            "expression":self.soul['expression'],
            "moolank_explaination":self.gni[str(self.moolank)],
            "bhagyank_explaination":self.gni[str(self.bhagyank)],
            "name_explaination":self.gni[str(self.name_number["s"])],
        }
    def years_predict(self):
        self.years = [self.unitization([int(j) for j in list(str(self.d +self.m +i))]) for i in range(self.y,self.y+100,1)]
        self.information1 = {}
        self.information2 = {}
        self.yc = 0
        for i in range(self.y,self.y+100,1):
            self.information1[i] = self.years[self.yc]
            self.information2[i] = self.unitization([int(u) for u in list(str(i))])
            self.yc += 1
        return {"cy":self.information1,"yt":self.information2}
def NCEU_executor(d,m,y,n,g,yf):
    data = NCEU(d,m,y,n,g,yf)
    return data.general_calculation(),data.lsg(),data.vg(),data.years_predict()

# print(NCEU_executor(22,7,2005,"akshay sethi","male",True))
from flask import *
from engine import NCEU_executor
import firebase_admin
from firebase_admin import credentials
from firebase_admin import auth
cred = credentials.Certificate("key.json")
firebase_admin.initialize_app(cred)

app = Flask(__name__)
@app.route("/",methods=['POST','GET'])
def index():
    return render_template("index.html")

@app.route("/login",methods=['POST','GET'])
def login():
    if request.method == 'POST':
        if len(request.form) == 3:
            try:
                user_present = auth.get_user_by_email(request.form['email'])
                return redirect("/messege/email-exists") # email exist messages
            except Exception as e:        
                try:
                    user = auth.create_user(
                        email=request.form['email'],
                        email_verified=False,
                        password=request.form['password'],
                        display_name=request.form['name'],
                        disabled=False
                    )
                    print(user)  # account created 
                except Exception as e:
                    return redirect("/messege/password-length-exceed") #return error 
        return render_template("login.html") # REMOVE TO BE LATER
    return render_template("login.html")

@app.route("/messege/<data>")
def messege(data):
    msg_data = {
        "password-length-exceed":"your password must contain minimum 6 characters",
        "email-exists":"email already exists. kindly login from your email or create your new account with new email"
    }
    if data in list(msg_data.keys()):
        return render_template("error.html",msg=data)
    return redirect('index')

if __name__ == '__main__':
    app.run(port=3000,debug=True)

"""
if request.method == 'POST':
        name = request.form['text']
        dt = request.form['dt']
        gender = request.form['gender']
        ysf = request.form['factor']
        if ysf == '0':
            ysf = True
        else:
            ysf = False
        dt = [int(i) for i in dt.split('-')]

        print(name)
        print(dt)
        print(gender)
        print(ysf)
        data = NCEU_executor(dt[2],dt[1],dt[0],name,gender,ysf)
        return jsonify(data)
"""